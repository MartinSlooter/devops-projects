# PodSmith DevOps Template – DevPod + mise + Neovim + tmux

Isolated, reproducible development environments for client DevOps work.

Built for:
- **DevPod** (primary workflow)
- **mise** (tool version management)
- **Neovim** + **tmux**
- **Podman** (recommended) or Docker
- Works with VS Code / Cursor as well

## Features

| Component        | Status                          |
|------------------|---------------------------------|
| DevPod           | Primary entry point             |
| mise             | Tool versions pinned in `mise.toml` |
| Neovim + tmux    | Pre-installed                   |
| Terraform        | Pre-installed + managed by mise |
| kubectl / Helm / kind | Pre-installed              |
| AWS / Azure / GCP CLIs | Pre-installed             |
| Rootless Podman  | Supported                       |

## Prerequisites (host)

1. **Podman** (recommended) or Docker
2. **DevPod** CLI  
   ```bash
   # Linux example
   curl -L -o devpod "https://github.com/loft-sh/devpod/releases/latest/download/devpod-linux-amd64" \
     && sudo install -c -m 0755 devpod /usr/local/bin/devpod
   ```
3. (Optional) Configure DevPod to use Podman:
   ```bash
   devpod provider add docker
   # Then edit the provider so the Docker path points to podman, or:
   devpod provider use docker
   # Set DOCKER_HOST or configure the provider to use the Podman socket
   ```

## Quick Start with DevPod

```bash
# 1. Clone / copy this template into a new client project
cp -r podsmith-devops-template my-client
cd my-client
git init

# 2. Start the workspace
devpod up .

# 3. Enter the workspace
devpod ssh
# or open with an IDE:
# devpod up . --ide nvim          # if configured
# devpod up . --ide vscode
```

Inside the container you already have:
- Neovim (`nvim`)
- tmux
- mise + all tools from `mise.toml`
- Terraform, kubectl, Helm, kind, AWS/Azure/GCP CLIs

## Daily workflow

```bash
cd my-client
devpod up .          # starts (or resumes) the workspace
devpod ssh           # enter the container
```

Inside:
```bash
mise ls              # see installed tools
mise install         # update tools if mise.toml changed
nvim                 # edit files
tmux new -s work     # start a tmux session
kind create cluster --name client-local
```

Stop when finished:
```bash
devpod stop
# or
devpod delete        # completely remove the workspace
```

## Using with VS Code / Cursor (optional)

Open the folder and choose **“Dev Containers: Reopen in Container”**.  
The same `.devcontainer/devcontainer.json` is used.

## Customising tools

Edit `mise.toml` and run:

```bash
mise install
```

Common additions:
```toml
[tools]
terraform = "1.9"
kubectl = "1.31"
helm = "3.16"
k9s = "latest"
python = "3.12"
node = "22"
```

## Project structure

```
.
├── .devcontainer/
│   └── devcontainer.json      # Dev Containers / DevPod config
├── docker/
│   ├── Dockerfile             # Base image + Neovim, tmux, mise, cloud CLIs
│   └── entrypoint.sh
├── scripts/
│   └── setup.sh               # postCreateCommand – runs mise install
├── mise.toml                  # Pin tool versions here
├── .gitignore
└── README.md
```

## Tips for client isolation

- One Git repository (and one DevPod workspace) per client.
- Keep secrets in a git-ignored `.env` file.
- Never install client-specific tools on the host – everything lives in the container.
- Use different workspace names if you work on multiple clients simultaneously:
  ```bash
  devpod up . --id client-a
  ```

## Switching between Podman and Docker

DevPod’s default provider is Docker. To force Podman:

```bash
# Point the docker provider at podman
export DOCKER_HOST=unix://$XDG_RUNTIME_DIR/podman/podman.sock
devpod up .
```

Or configure the provider permanently in DevPod Desktop / CLI settings.
