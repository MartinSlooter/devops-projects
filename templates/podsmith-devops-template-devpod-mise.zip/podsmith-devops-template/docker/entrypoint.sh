#!/usr/bin/env bash
set -euo pipefail

# Load project .env if present
if [ -f /workspaces/.env ] || [ -f .env ]; then
  set -a
  # shellcheck disable=SC1091
  source /workspaces/.env 2>/dev/null || source .env 2>/dev/null || true
  set +a
fi

# Ensure mise is activated
eval "$(mise activate bash)" 2>/dev/null || true

# Make sure common dirs exist
mkdir -p ~/.kube ~/.local/share/mise ~/.config/mise

exec "$@"
