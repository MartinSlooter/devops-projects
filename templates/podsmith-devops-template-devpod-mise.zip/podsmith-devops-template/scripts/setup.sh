#!/usr/bin/env bash
set -euo pipefail

echo "==> Trusting and installing tools via mise..."

# Trust the project mise.toml so it can run without prompts
if [ -f mise.toml ]; then
  mise trust mise.toml
  mise install
else
  echo "No mise.toml found – skipping mise install"
fi

echo "==> Setup complete"
echo "Neovim : $(nvim --version | head -1)"
echo "tmux   : $(tmux -V)"
echo "mise   : $(mise --version)"
echo ""
echo "Useful commands:"
echo "  mise ls          # list installed tools"
echo "  mise install     # install/update tools from mise.toml"
echo "  nvim             # start Neovim"
echo "  tmux             # start tmux"
echo "  kind create cluster --name local"
